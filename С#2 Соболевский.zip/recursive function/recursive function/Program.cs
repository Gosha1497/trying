﻿using System;

namespace recursive_function
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите два числа, при том что первое меньше второго");
            int a = Convert.ToInt32(Console.ReadLine());
            int b = Convert.ToInt32(Console.ReadLine());
            if (a < b) { 
            int rec = (a + b) * (b - a + 1) / 2;
            Console.WriteLine("Сумма чисел от а до b"+" "+rec);
            }
            else { Console.WriteLine("А проверь ка ты введенные данные)?"); }
        }
    }
}
