﻿using System;

namespace autorisation
{
    class Program
    {
        static void Main()
        {
            Console.WriteLine("Здравствуйте. Для продолжения войдите в систему. Введите сначала логин, затем пароль.");
            string a = Console.ReadLine();
            string b = Console.ReadLine();
            int count = 0;
            do
            {
                if (a == "root" && b == "GeekBrains")
                {
                    Console.WriteLine("Логин подтвержден");
                    Console.WriteLine("Пароль подтвержден");
                    break;
                }
                else { Console.WriteLine("Попробуйте еще раз, а пока насладитесь перспективой, что через уже две попытки аккаунт будет удален))"); count ++ ; }
            }
            while (count == 3);
        }

    }
}
