﻿using System;

namespace lesson2Task1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            int b = 10;
            int c = 6;
            int min;
            if (a < b && a < c) { min = a; }
            else if (a > b && b < c) { min = b; }
            else { min = c; }
            Console.WriteLine(min);
            Console.ReadKey();
        }
    }
}
