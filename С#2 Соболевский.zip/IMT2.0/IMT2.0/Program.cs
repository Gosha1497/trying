﻿using System;

namespace IMT2._0
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("18.5 24.8");
          int  m = Convert.ToInt32(Console.ReadLine());
          int  h = Convert.ToInt32(Console.ReadLine());
          int IMT = m / h ^ 2;
          if (18.5<IMT && IMT < 24.8)
            { Console.WriteLine("Ваш ИМТ в норме))"+" "+ IMT); }
          else if (IMT > 24.8) { Console.WriteLine("Вам стоит сходить в спортзал 0_0" + " " + IMT); }
          else { Console.WriteLine("И как вас ветром не уносит)) 0_0" + " " + IMT); }
        }
    }
}
