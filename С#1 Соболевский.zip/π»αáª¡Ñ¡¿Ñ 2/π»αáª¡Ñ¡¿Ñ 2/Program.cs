﻿using System;

namespace упражнение_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Соболевский" + "" + " Рассчитать и вывести индекс массы тела (ИМТ) по формуле I=m/(h*h); где m — масса тела в килограммах, h — рост в метрах");
            Console.WriteLine($"Пожалуйста укажите ваш рост");
            double h = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"А теперь укажите ваш вес");
            double m = Convert.ToDouble(Console.ReadLine());
            double l = m / (h * 2);
            Console.WriteLine($"Ваш Индекс Массы Тела =" + "" + l * 100);
            Console.ReadLine();
        }
    }
}
