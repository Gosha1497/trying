﻿using System;

namespace reverse
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Соболевский" + "" + " Программа обмена значений переменных");
            Console.WriteLine($"Пожалуйста укажите значение первой переменной");
            double a = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine($"А теперь укажите значение второй переменной");
            double b = Convert.ToDouble(Console.ReadLine());
            double c = a;
            a = b;
            b = c;
            Console.WriteLine("Теперь переменная а стала равна" + " " + a + ", " + "а переменная b стала равна" + " " + b);
            Console.ReadLine();
        }
    }
}
